<template>
  <div class="container">
    <h2 class="my-4">Productos</h2>

    <div class="mb-4">
      <select v-model="selectedCategory" @change="filterByCategory" class="form-select">
        <option value="">Todas las categorías</option>
        <option v-for="category in categories" :key="category" :value="category">
          {{ category }}
        </option>
      </select>
    </div>

    <div class="row gap-2">
      <ProductCard
        v-for="product in filteredProducts"
        :key="product.id"
        :product="product"
        @add-to-cart="handleAddToCart"
        class="col-md-3 mb-4"
      />
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted } from 'vue';
import { fetchProducts, fetchCategories } from '../api/productService';
import ProductCard from '../components/ProductCard.vue';
import { Product, Category } from '../types/products';
import { useStore } from 'vuex';

export default defineComponent({
  name: 'HomePage',
  components: {
    ProductCard
  },
  setup() {
    const store = useStore();
    const products = ref<Product[]>([]);
    const categories = ref<Category[]>([]);
    const selectedCategory = ref('');
    const filteredProducts = ref<Product[]>([]);

    onMounted(async () => {
      products.value = await fetchProducts();
      categories.value = await fetchCategories();
      filteredProducts.value = products.value;
    });

    const filterByCategory = () => {
      if (selectedCategory.value) {
        filteredProducts.value = products.value.filter(
          (product: Product) => product.category === selectedCategory.value
        );
      } else {
        filteredProducts.value = products.value;
      }
    };

    const handleAddToCart = (product: Product) => {
      // Aquí se utiliza Vuex para agregar el producto al carrito
      store.commit('addToCart', { ...product, quantity: 1 });
      console.log("Producto agregado al carrito", product);
    };

    return {
      products,
      categories,
      selectedCategory,
      filteredProducts,
      filterByCategory,
      handleAddToCart
    };
  }
});
</script>

<style scoped>
</style>
