<template>
  <div class="container">
    <h2 class="my-4">Tu Carrito</h2>

    <div v-if="cart.length > 0">
      <ul class="list-group">
        <li v-for="item in cart" :key="item.id" class="list-group-item d-flex justify-content-between align-items-center">
          <span>{{ item.name }} - ${{ item.price.toFixed(2) }}</span>

          <div class="d-flex align-items-center">
            <button @click="decreaseQuantity(item)" class="btn btn-secondary btn-sm">-</button>
            <span class="mx-2">{{ item.quantity }}</span>
            <button @click="increaseQuantity(item)" class="btn btn-secondary btn-sm">+</button>
          </div>

          <span>${{ (item.price * item.quantity).toFixed(2) }}</span>
        </li>
      </ul>
      <p class="mt-3">
        <strong v-bind:title="'Total: $' + totalPrice.toFixed(2)">
          Total: ${{ totalPrice.toFixed(2) }}
        </strong>
      </p>

    </div>
    <div v-else>
      <p>Tu carrito está vacío.</p>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, computed } from 'vue';
import { useStore } from 'vuex';
import { Product } from '../types/products';

export default defineComponent({
  name: 'CartPage',
  setup() {
    const store = useStore();

    // Obtener el carrito desde Vuex
    const cart = computed(() => store.state.cart);

    // Obtener el total general desde el getter de Vuex
    const totalPrice = computed(() => store.getters.totalPrice);

    // Métodos para aumentar y disminuir la cantidad de productos en el carrito
    const increaseQuantity = (item: Product) => {
      store.commit('increaseQuantity', item.id);
    };

    const decreaseQuantity = (item: Product) => {
      store.commit('decreaseQuantity', item.id);
    };

    return {
      cart,
      totalPrice,
      increaseQuantity,
      decreaseQuantity
    };
  }
});
</script>

<style scoped></style>
