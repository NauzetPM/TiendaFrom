import axios from 'axios';
import {Product,Category} from '../types/products'
export const fetchProducts = async () => {
  const response = await axios.get('/products.json'); 
  return response.data;
}

export const fetchCategories = async (): Promise<Category[]> => {
  const response = await axios.get('/products.json');
  const products: Product[] = response.data;
  const categories = [...new Set(products.map((product) => product.category))];
  return categories;
}

