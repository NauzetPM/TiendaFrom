<template>
  <div class="bg-color1 full-screen">
    <Navbar />
    <div class="container my-4 ">
      <router-view></router-view> 
    </div>
  </div>
</template>

<script lang="ts">
import Navbar from './components/Navbar.vue';

export default {
  name: 'App',
  components: {
    Navbar,
  }
};
</script>

<style scoped>
html, body {
  height: 100%; 
  margin: 0; 
}
.full-screen {
  height: 100vh;
  width: 100%;
}
</style>
