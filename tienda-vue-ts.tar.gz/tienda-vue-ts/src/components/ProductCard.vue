<template>
  <div class="card" style="width: 18rem;">
    <img :src="product?.image" class="card-img-top" alt="Producto" />
    <div class="card-body">
      <h5 class="card-title">{{ product?.name }}</h5>
      <p class="card-text">${{ product?.price?.toFixed(2) }}</p>
      <button @click="addToCart(product)" class="btn btn-primary">
        Añadir al carrito
      </button>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  props: {
    product: {
      type: Object as () => { id: number; image: string; name: string; price: number } | undefined,
      default: () => ({ id: 0, image: '', name: '', price: 0 })
    }
  },
  methods: {
    addToCart(product: any) {
      // Emitimos el producto al componente principal
      this.$emit('add-to-cart', { ...product, quantity: 1 });
    }
  }
});
</script>

<style scoped>
</style>
