// src/store/store.ts
import { createStore } from 'vuex';
import { Product } from "../types/products";

export default createStore({
  state: {
    cart: [] as Product[] // Asegúrate de que 'Product' sea la interfaz correcta
  },
  mutations: {
    addToCart(state, product: Product) {
      const existingProduct = state.cart.find(item => item.id === product.id);
      if (existingProduct) {
        existingProduct.quantity += 1;
      } else {
        state.cart.push({...product, quantity: 1});
      }
    },
    increaseQuantity(state, productId: number) {
      const product = state.cart.find(item => item.id === productId);
      if (product) {
        product.quantity += 1;
      }
    },
    decreaseQuantity(state, productId: number) {
      const product = state.cart.find(item => item.id === productId);
      if (product && product.quantity > 1) {
        product.quantity -= 1;
      }
    }
  },
  getters: {
    totalPrice(state) {
      return state.cart.reduce((total, item) => total + item.price * item.quantity, 0);
    }
  }
});
